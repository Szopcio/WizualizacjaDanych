#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,wynik=0;
    printf("n: ");
    scanf("%d",&n);
    if (n>2)
    {
        if (n%2==0)
        {
            for(int i=0;wynik<n;i++)
            {
                wynik+=2;
                printf("%d*",wynik);
            }
        }
        else
            for(int i=0;wynik<(n-1);i++)
            {
                wynik+=2;
                printf("%d*",wynik);
            }

    }
    else
        printf("za malo");
    return 0;
}
