#include <stdio.h>
#include <stdlib.h>

void liczwywolan ()
{
    static int wywolan;
    wywolan++;
    printf("Liczba wywolan funkcji: %d\n",wywolan);
}

int main()
{
    int n;
    printf("n: ");
    scanf("%d",&n);
    while (n>0)
    {
        liczwywolan();
        n--;
    }
    return 0;
}
