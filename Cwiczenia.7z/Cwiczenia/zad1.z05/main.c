#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=6;
    int *p;
    p=&a;
    printf("adres a: %x\n",&a);
    printf("wartosc i adres a: %d %x\n",*&a);
    printf("wartosc p: %d\n",*p);
    printf("adres p: %x\n",&p);
    printf("wartosc i adres p: %d %x\n",*&p);
    printf("adres i wartosc p: %d %x\n",&*p);
    return 0;
}
