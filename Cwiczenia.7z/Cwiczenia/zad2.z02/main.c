#include <stdio.h>
#include <stdlib.h>

double najmniejsza(double x,double y,double z)
{
    if (x<y && x<z)
        return x;
    else
    {
        if (y<z)
            return y;
        else
            return z;
    }
}

int main()
{
    double x,y,z;
    printf("x: ");
    scanf("%f",&x);
    printf("y: ");
    scanf("%f",&y);
    printf("z: ");
    scanf("%f",&z);
    printf("Najmniejsza wartosc: %f",najmniejsza(x,y,z));
    return 0;
}
