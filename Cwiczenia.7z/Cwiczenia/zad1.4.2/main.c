#include <stdio.h>
#include <stdlib.h>

int main()
{
    int m,n,wynik=0;
    printf("m: ");
    scanf("%d",&m);
    printf("n: ");
    scanf("%d",&n);
    if (n>0 && m>0)
    {
        for (int i=1;i<=n;i++)
        {
            wynik+=m;
            printf("%d ",wynik);
        }
    }
    else
        printf("To nie sa(nie jest) dodatnie liczby\n");
    return 0;
}
