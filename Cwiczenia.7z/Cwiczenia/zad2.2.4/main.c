#include <stdio.h>
#include <stdlib.h>

int potdwojka (int n)
{
    int wynik=1;
    if (n==0)
    {
        wynik=1;
        return wynik;
    }
    else
        while (n>0)
        {
            wynik=wynik*2;
            n--;
        }
        return wynik;
}

int main()
{
    int n;
    printf("n: ");
    scanf("%d",&n);
    if (n<0)
        printf("Wpisz n>=0\n");
    else
        printf("Dwojka do potegi n: %d",(potdwojka(n)));
    return 0;
}
