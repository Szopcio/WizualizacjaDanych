#include <stdio.h>
#include <stdlib.h>

bool czyPita(int a,int b,int c)
{
    return (a*a+b*b==c*c);
}

int main()
{
    int n,a=3,b=4,c=(n-1);
    printf("n: ");
    scanf("%d",n);
    if (n>6)
    {
        for(int i=0;i<n;i++)
            {
                czyPita(a,b,c)
                if(czyPita)
                    printf("%d %d %d\n",a,b,c)
            }
    }
    return 0;
}
