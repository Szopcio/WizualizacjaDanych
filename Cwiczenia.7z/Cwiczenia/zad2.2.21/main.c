#include <stdio.h>
#include <stdlib.h>

int ciag (int n)
{
    int wynik=1;
    if (n==0)
        return 1;
    else
        while (n>0)
        {
            wynik=2*wynik+5;
            n--;
        }
        return wynik;
}

int main()
{
    int n;
    printf("n: ");
    scanf("%d",&n);
    printf("Wynik ciagu: %d",ciag(n));
    return 0;
}
