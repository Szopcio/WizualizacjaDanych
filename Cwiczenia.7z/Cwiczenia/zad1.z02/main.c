#include <stdio.h>
#include <stdlib.h>

int sgn(double x)
{
    if(x<0)
        return -1;
    if(x==0)
        return 0;
    if(x>0)
        return 1;
}

int main()
{
    double x;
    printf("x: ");
    scanf("%f",&x);
    printf("%d",sgn(x));
    return 0;
}
