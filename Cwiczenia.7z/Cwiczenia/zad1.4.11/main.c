#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
int a,b,c,d;
printf("Podaj a: \n");
scanf("%d",&a);
printf("Podaj b: \n");
scanf("%d",&b);
printf("Podaj c: \n");
scanf("%d",&c);
printf("Podaj d: \n");
scanf("%d",&d);
a=abs(a);
printf("%d",a);
}
