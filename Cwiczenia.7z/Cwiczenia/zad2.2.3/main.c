#include <stdio.h>
#include <stdlib.h>

int dzielik (int n)
{
    int k=n-1;
    while (k>0)
    {
        if (n%k==0)
            return k;
        else
            k--;
    }
}

int main()
{
    int n;
    printf("n: ");
    scanf("%d",&n);
    if (n<=2)
        printf("Wpisz n>2\n");
    else
        printf("Najwieksza liczba k taka, ze dzieli n: %d",(dzielik(n)));
    return 0;
}
