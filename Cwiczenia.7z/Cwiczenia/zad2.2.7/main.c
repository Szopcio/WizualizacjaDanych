#include <stdio.h>
#include <stdlib.h>

int potega (int n,int m)
{
    int wynik=1;
    if (m==0)
    {
        wynik=1;
        return wynik;
    }
    else
        m=abs(m);
        while (m>0)
        {
            wynik=wynik*n;
            m--;
        }
        return wynik;
}

int main()
{
    int n,m;
    printf("n: ");
    scanf("%d",&n);
    printf("m: ");
    scanf("%d",&m);
    if ((n==0) && (m==0))
        printf("Wpisz liczby, ktore co najmniej jedna jest rozna od 0\n");
    else
        if (m<0)
            printf("N do potegi m: 1/%d",(potega(n,m)));
        else
            printf("N do potegi m: %d",(potega(n,m)));
    return 0;
}

